package com.dicoding.appgithub_2.alarm.reminder

data class Reminder(var alarmReminder: Boolean = false)
