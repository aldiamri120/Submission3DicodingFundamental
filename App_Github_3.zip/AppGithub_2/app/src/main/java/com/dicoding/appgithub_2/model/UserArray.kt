package com.dicoding.appgithub_2.model

data class UserArray(val items: ArrayList<UserModel>)