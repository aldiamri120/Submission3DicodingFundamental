package com.dicoding.appgithub_2.model

data class UserModel(
    val login: String,
    val id: Int,
    val avatar_url: String
)
